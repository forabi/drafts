English  | عربي
--------:|:----------
Prototype | نموذج بدئي
Singleton | كائن متفرد
Observer | مراقب
Module | وحدة
Revealing Module | وحدة كاشفة
Constructor | مُشيّد
Class | صنف
Object | كائن
Public variable | متغير علنيّ
Private variable | متغير سرِّي
Global scope | النطاق العام
Namespace | فضاء الأسماء
Globals | كائنات مُعرّفة في النطاق العامّ
Method | وظيفة
Arguments | مُعامِلات
Square brackets | قوسان مُربّعان
Curly brackets | قوسان معكوفان
Function | دالّة
Instance | نسخة
String | سلسلة نصّيّة
Object literal | كائن حرفيّ
Block | قطعة برمجيّة
Caching | تخزين مؤقّت
Closure | دالّة مغلقة
API | واجهة برمجية
Interface | واجهة
Debugger | منقّح
Debug | يُنقِّح
Bug | علّة
Local | محليّ
Subject (in Observer Pattern) | فاعل
Subscriber | مُشترك
Event | حدث
Static | ثابت
Statically-typed programming language | لغة برمجة ثابتة الأنواع
Dynamically-typed programming language | لغة برمجة متغيّرة الأنواع
Factory | معمل
Initialization | تهيئة
Concrete | مرئيّ
Checkbox | مربّع اختيار
Publish/Subscribe | الاشتراك/النشر
Event handling | تولّي الأحداث
Library | مكتبة
Log | سجِلّ
Template | قالب
Request | طلب
Response | جواب
Return | إعادة/إرجاع
Access modifiers | مستويات الوصول إلى المتغيّرات
Exception | استثناء
User Agent | عميل المستخدم

